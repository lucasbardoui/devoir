﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Banque.BOL;
using Banque.DAL;
using System.Windows.Forms;

namespace Banque.WindowsGUI
{
    public partial class FrmVirement : Form
    {
        public FrmVirement()
        {
            InitializeComponent();
            DatePrelevement.Value = DateTime.Now;
            LabelDate.Text = "Entre le " + DateTime.Now.Date + " et le " + DateTime.Now.Date + 10;
            clientBindingSource.DataSource = Globale.Client;
            compteBindingSource.DataSource = Globale.Client.Comptes;
            compteBindingSource1.DataSource = Globale.Client.Comptes;
           // compteBindingSource1.DataSource = CompteExterneDAC.Instance.Client(Globale.Client.CodeClient);

            compteComboBox.SelectedIndex = 1;
            compteComboBox1.SelectedIndex = 0;

        }
        /// <summary>
        /// Si sortie du dialogue modal avec OK
        /// Raffraichissement de la liste déroulante des comptes destinataires
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCreerCompte_Click(object sender, EventArgs e)
        {
            FrmNouveauCompte frmNouveauCompte = new FrmNouveauCompte();
            if (frmNouveauCompte.ShowDialog() == DialogResult.OK)
            {

            }
        }
        /// <summary>Banque
        /// Si aucune erreur, validation et enregistrement dans la base de données
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnValiderVirement_Click(object sender, EventArgs e)
        {
            Compte Emetteur = new Compte();
            Emetteur = (Compte)compteBindingSource.Current;

            Compte Destinateur = new Compte();
            Destinateur = (Compte)compteBindingSource1.Current;



            CheckComboBox();
            if (OnlyChiffre(Montanttxt.Text) == false || NoNull(Montanttxt.Text) == false)
            {
                errorProvider1.SetError(Montanttxt, "Inserer uniquement des chiffres. Champs obligatoire.");
            }
            else
            {
                errorProvider1.SetError(Montanttxt, "");
                double Montant = Convertion(Montanttxt.Text);
                double Solde = Convertion(soldeLabel1.Text);
                if (Montant > Solde)
                {
                    errorProvider1.SetError(btnValiderVirement, "Erreur Montant");
                }
                else
                {
                    errorProvider1.SetError(btnValiderVirement, "");
                }
            }
            if (errorProvider1.GetError(btnValiderVirement) == "" && errorProvider1.GetError(DatePrelevement) == "" && errorProvider1.GetError(Montanttxt) == "")
            {
                FrmAcceptation dialogue = new FrmAcceptation(Montanttxt.Text, libelleCompteTextBox.Text, libelleCompteTextBox1.Text);
                DialogResult res = dialogue.ShowDialog();
                if (res == DialogResult.OK)
                {
                    CompteDAC.Instance.Ajout_Virement(Emetteur, Destinateur, Convertion(Montanttxt.Text),TxtMotif.Text,textBox3.Text);
                }
                else
                {
                    FrmAnnul annul = new FrmAnnul();
                    annul.ShowDialog();
                }
            }
        }

        private void DatePrelevement_ValueChanged(object sender, EventArgs e)
        {
            if (DatePrelevement.Value < DateTime.Now.Date || DatePrelevement.Value > (DateTime.Now.Date.AddDays(10)))
            {
                errorProvider1.SetError(DatePrelevement, "La date doit etre comprise entre aujourd'hui et J+10.");
            }
            else
            {
                errorProvider1.SetError(DatePrelevement, "");
            }
        }

        private void Montanttxt_TextChanged(object sender, EventArgs e)
        {

        }

        private double Convertion(string convert)
        {
            convert.Replace(',', '.');
            return double.Parse(convert);

        }

        private bool NoNull(string test)
        {
            if (string.IsNullOrWhiteSpace(test))
            {
                return false;
            }
            return true;
        }

        private bool OnlyChiffre(string test)
        {
            foreach (char item in test)
            {
                if (!char.IsDigit(item))
                {
                    if (item == ',') { }
                    else
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        private void CheckComboBox()
        {
            if (compteComboBox.SelectedItem == compteComboBox1.SelectedItem)
            {
                errorProvider1.SetError(btnValiderVirement, " L'emetteur doit etre different du destinataire ");
            }
            else
            {
                errorProvider1.SetError(btnValiderVirement, "");
            }
        }

        private void compteComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (compteComboBox.SelectedItem == compteComboBox1.SelectedItem)
            {
                if (compteComboBox1.SelectedIndex == 0)
                {
                    compteComboBox1.SelectedIndex++;
                }
                else { compteComboBox1.SelectedIndex--; }
            }
        }

        private void compteComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (compteComboBox.SelectedItem == compteComboBox1.SelectedItem)
            {
                if (compteComboBox.SelectedIndex == 0)
                {
                    compteComboBox.SelectedIndex++;
                }
                else { compteComboBox.SelectedIndex--; }
            }
        }
    }
}
