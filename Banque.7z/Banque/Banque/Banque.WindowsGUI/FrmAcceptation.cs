﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banque.WindowsGUI
{
    public partial class FrmAcceptation : Form
    {
        public FrmAcceptation()
        {
            InitializeComponent();
        }

        public FrmAcceptation(string Montant, string emetteur, string destinateur):this()
        {
            Label.Text = "Vouler-vous envoyer " + Montant + "euro de "+ emetteur + " a " + destinateur;
        }

        private void BtnValid_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void Btnquitt_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
