﻿namespace Banque.WindowsGUI
{
    partial class FrmVirement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label codeClientLabel;
            System.Windows.Forms.Label nomClientLabel;
            System.Windows.Forms.Label prénomClientLabel;
            System.Windows.Forms.Label dateDerniereConnexionLabel;
            System.Windows.Forms.Label libelleCompteLabel;
            System.Windows.Forms.Label libelleCompteLabel1;
            System.Windows.Forms.Label soldeLabel;
            this.gbClient = new System.Windows.Forms.GroupBox();
            this.gbAdressePostale = new System.Windows.Forms.GroupBox();
            this.villeTextBox = new System.Windows.Forms.TextBox();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.codePostalTextBox = new System.Windows.Forms.TextBox();
            this.adresse2TextBox = new System.Windows.Forms.TextBox();
            this.adresse1TextBox = new System.Windows.Forms.TextBox();
            this.dateDerniereConnexionDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.prénomClientTextBox = new System.Windows.Forms.TextBox();
            this.nomClientTextBox = new System.Windows.Forms.TextBox();
            this.codeClientTextBox = new System.Windows.Forms.TextBox();
            this.gbNouveauVirement = new System.Windows.Forms.GroupBox();
            this.soldeLabel1 = new System.Windows.Forms.Label();
            this.compteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.compteComboBox1 = new System.Windows.Forms.ComboBox();
            this.compteBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.compteComboBox = new System.Windows.Forms.ComboBox();
            this.BtnCreerCompte = new System.Windows.Forms.Button();
            this.gbCaracteristiques = new System.Windows.Forms.GroupBox();
            this.compteComboBox2 = new System.Windows.Forms.ComboBox();
            this.LabelDate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtMotif = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DatePrelevement = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.Montanttxt = new System.Windows.Forms.TextBox();
            this.libelleCompteTextBox1 = new System.Windows.Forms.TextBox();
            this.libelleCompteTextBox = new System.Windows.Forms.TextBox();
            this.btnAnnulerVirement = new System.Windows.Forms.Button();
            this.btnValiderVirement = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            codeClientLabel = new System.Windows.Forms.Label();
            nomClientLabel = new System.Windows.Forms.Label();
            prénomClientLabel = new System.Windows.Forms.Label();
            dateDerniereConnexionLabel = new System.Windows.Forms.Label();
            libelleCompteLabel = new System.Windows.Forms.Label();
            libelleCompteLabel1 = new System.Windows.Forms.Label();
            soldeLabel = new System.Windows.Forms.Label();
            this.gbClient.SuspendLayout();
            this.gbAdressePostale.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.gbNouveauVirement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.compteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.compteBindingSource1)).BeginInit();
            this.gbCaracteristiques.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // codeClientLabel
            // 
            codeClientLabel.AutoSize = true;
            codeClientLabel.Location = new System.Drawing.Point(24, 28);
            codeClientLabel.Name = "codeClientLabel";
            codeClientLabel.Size = new System.Drawing.Size(64, 13);
            codeClientLabel.TabIndex = 0;
            codeClientLabel.Text = "Code Client:";
            // 
            // nomClientLabel
            // 
            nomClientLabel.AutoSize = true;
            nomClientLabel.Location = new System.Drawing.Point(24, 54);
            nomClientLabel.Name = "nomClientLabel";
            nomClientLabel.Size = new System.Drawing.Size(61, 13);
            nomClientLabel.TabIndex = 2;
            nomClientLabel.Text = "Nom Client:";
            // 
            // prénomClientLabel
            // 
            prénomClientLabel.AutoSize = true;
            prénomClientLabel.Location = new System.Drawing.Point(24, 80);
            prénomClientLabel.Name = "prénomClientLabel";
            prénomClientLabel.Size = new System.Drawing.Size(75, 13);
            prénomClientLabel.TabIndex = 4;
            prénomClientLabel.Text = "Prénom Client:";
            // 
            // dateDerniereConnexionLabel
            // 
            dateDerniereConnexionLabel.AutoSize = true;
            dateDerniereConnexionLabel.Location = new System.Drawing.Point(25, 109);
            dateDerniereConnexionLabel.Name = "dateDerniereConnexionLabel";
            dateDerniereConnexionLabel.Size = new System.Drawing.Size(103, 13);
            dateDerniereConnexionLabel.TabIndex = 6;
            dateDerniereConnexionLabel.Text = "Dernière Connexion:";
            // 
            // libelleCompteLabel
            // 
            libelleCompteLabel.AutoSize = true;
            libelleCompteLabel.Location = new System.Drawing.Point(16, 31);
            libelleCompteLabel.Name = "libelleCompteLabel";
            libelleCompteLabel.Size = new System.Drawing.Size(58, 13);
            libelleCompteLabel.TabIndex = 14;
            libelleCompteLabel.Text = "Emetteur : ";
            // 
            // libelleCompteLabel1
            // 
            libelleCompteLabel1.AutoSize = true;
            libelleCompteLabel1.Location = new System.Drawing.Point(16, 57);
            libelleCompteLabel1.Name = "libelleCompteLabel1";
            libelleCompteLabel1.Size = new System.Drawing.Size(72, 13);
            libelleCompteLabel1.TabIndex = 15;
            libelleCompteLabel1.Text = "Destinataire : ";
            // 
            // soldeLabel
            // 
            soldeLabel.AutoSize = true;
            soldeLabel.Location = new System.Drawing.Point(344, 39);
            soldeLabel.Name = "soldeLabel";
            soldeLabel.Size = new System.Drawing.Size(48, 17);
            soldeLabel.TabIndex = 11;
            soldeLabel.Text = "Solde:";
            // 
            // gbClient
            // 
            this.gbClient.Controls.Add(this.gbAdressePostale);
            this.gbClient.Controls.Add(dateDerniereConnexionLabel);
            this.gbClient.Controls.Add(this.dateDerniereConnexionDateTimePicker);
            this.gbClient.Controls.Add(prénomClientLabel);
            this.gbClient.Controls.Add(this.prénomClientTextBox);
            this.gbClient.Controls.Add(nomClientLabel);
            this.gbClient.Controls.Add(this.nomClientTextBox);
            this.gbClient.Controls.Add(codeClientLabel);
            this.gbClient.Controls.Add(this.codeClientTextBox);
            this.gbClient.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gbClient.Location = new System.Drawing.Point(12, 12);
            this.gbClient.Name = "gbClient";
            this.gbClient.Size = new System.Drawing.Size(669, 155);
            this.gbClient.TabIndex = 0;
            this.gbClient.TabStop = false;
            this.gbClient.Text = "Vos Coordonnées";
            // 
            // gbAdressePostale
            // 
            this.gbAdressePostale.Controls.Add(this.villeTextBox);
            this.gbAdressePostale.Controls.Add(this.codePostalTextBox);
            this.gbAdressePostale.Controls.Add(this.adresse2TextBox);
            this.gbAdressePostale.Controls.Add(this.adresse1TextBox);
            this.gbAdressePostale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAdressePostale.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gbAdressePostale.Location = new System.Drawing.Point(354, 11);
            this.gbAdressePostale.Name = "gbAdressePostale";
            this.gbAdressePostale.Size = new System.Drawing.Size(289, 130);
            this.gbAdressePostale.TabIndex = 8;
            this.gbAdressePostale.TabStop = false;
            this.gbAdressePostale.Text = "Votre adresse";
            // 
            // villeTextBox
            // 
            this.villeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Ville", true));
            this.villeTextBox.Location = new System.Drawing.Point(83, 87);
            this.villeTextBox.Name = "villeTextBox";
            this.villeTextBox.ReadOnly = true;
            this.villeTextBox.Size = new System.Drawing.Size(180, 21);
            this.villeTextBox.TabIndex = 6;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            // 
            // codePostalTextBox
            // 
            this.codePostalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "CodePostal", true));
            this.codePostalTextBox.Location = new System.Drawing.Point(6, 87);
            this.codePostalTextBox.Name = "codePostalTextBox";
            this.codePostalTextBox.ReadOnly = true;
            this.codePostalTextBox.Size = new System.Drawing.Size(68, 21);
            this.codePostalTextBox.TabIndex = 5;
            // 
            // adresse2TextBox
            // 
            this.adresse2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Adresse2", true));
            this.adresse2TextBox.Location = new System.Drawing.Point(6, 59);
            this.adresse2TextBox.Name = "adresse2TextBox";
            this.adresse2TextBox.ReadOnly = true;
            this.adresse2TextBox.Size = new System.Drawing.Size(257, 21);
            this.adresse2TextBox.TabIndex = 3;
            // 
            // adresse1TextBox
            // 
            this.adresse1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "Adresse1", true));
            this.adresse1TextBox.Location = new System.Drawing.Point(6, 32);
            this.adresse1TextBox.Name = "adresse1TextBox";
            this.adresse1TextBox.ReadOnly = true;
            this.adresse1TextBox.Size = new System.Drawing.Size(257, 21);
            this.adresse1TextBox.TabIndex = 1;
            // 
            // dateDerniereConnexionDateTimePicker
            // 
            this.dateDerniereConnexionDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.clientBindingSource, "DateDerniereConnexion", true));
            this.dateDerniereConnexionDateTimePicker.Enabled = false;
            this.dateDerniereConnexionDateTimePicker.Location = new System.Drawing.Point(134, 103);
            this.dateDerniereConnexionDateTimePicker.Name = "dateDerniereConnexionDateTimePicker";
            this.dateDerniereConnexionDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDerniereConnexionDateTimePicker.TabIndex = 7;
            // 
            // prénomClientTextBox
            // 
            this.prénomClientTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "PrénomClient", true));
            this.prénomClientTextBox.Location = new System.Drawing.Point(134, 77);
            this.prénomClientTextBox.Name = "prénomClientTextBox";
            this.prénomClientTextBox.ReadOnly = true;
            this.prénomClientTextBox.Size = new System.Drawing.Size(151, 20);
            this.prénomClientTextBox.TabIndex = 5;
            // 
            // nomClientTextBox
            // 
            this.nomClientTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "NomClient", true));
            this.nomClientTextBox.Location = new System.Drawing.Point(134, 51);
            this.nomClientTextBox.Name = "nomClientTextBox";
            this.nomClientTextBox.ReadOnly = true;
            this.nomClientTextBox.Size = new System.Drawing.Size(151, 20);
            this.nomClientTextBox.TabIndex = 3;
            // 
            // codeClientTextBox
            // 
            this.codeClientTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.clientBindingSource, "CodeClient", true));
            this.codeClientTextBox.Location = new System.Drawing.Point(134, 25);
            this.codeClientTextBox.Name = "codeClientTextBox";
            this.codeClientTextBox.ReadOnly = true;
            this.codeClientTextBox.Size = new System.Drawing.Size(100, 20);
            this.codeClientTextBox.TabIndex = 1;
            // 
            // gbNouveauVirement
            // 
            this.gbNouveauVirement.Controls.Add(soldeLabel);
            this.gbNouveauVirement.Controls.Add(this.soldeLabel1);
            this.gbNouveauVirement.Controls.Add(this.compteComboBox1);
            this.gbNouveauVirement.Controls.Add(this.compteComboBox);
            this.gbNouveauVirement.Controls.Add(this.BtnCreerCompte);
            this.gbNouveauVirement.Controls.Add(this.gbCaracteristiques);
            this.gbNouveauVirement.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbNouveauVirement.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gbNouveauVirement.Location = new System.Drawing.Point(12, 183);
            this.gbNouveauVirement.Name = "gbNouveauVirement";
            this.gbNouveauVirement.Size = new System.Drawing.Size(884, 967);
            this.gbNouveauVirement.TabIndex = 1;
            this.gbNouveauVirement.TabStop = false;
            this.gbNouveauVirement.Text = "Pour effectuer un nouveau virement";
            // 
            // soldeLabel1
            // 
            this.soldeLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.compteBindingSource, "Solde", true));
            this.soldeLabel1.Location = new System.Drawing.Point(398, 39);
            this.soldeLabel1.Name = "soldeLabel1";
            this.soldeLabel1.Size = new System.Drawing.Size(100, 23);
            this.soldeLabel1.TabIndex = 12;
            this.soldeLabel1.Text = "label5";
            // 
            // compteBindingSource
            // 
            this.compteBindingSource.DataSource = typeof(Banque.BOL.Compte);
            // 
            // compteComboBox1
            // 
            this.compteComboBox1.DataSource = this.compteBindingSource1;
            this.compteComboBox1.DisplayMember = "LibelleCompte";
            this.compteComboBox1.FormattingEnabled = true;
            this.compteComboBox1.Location = new System.Drawing.Point(18, 83);
            this.compteComboBox1.Name = "compteComboBox1";
            this.compteComboBox1.Size = new System.Drawing.Size(300, 24);
            this.compteComboBox1.TabIndex = 11;
            this.compteComboBox1.ValueMember = "CodeClient";
            this.compteComboBox1.SelectedIndexChanged += new System.EventHandler(this.compteComboBox1_SelectedIndexChanged);
            // 
            // compteBindingSource1
            // 
            this.compteBindingSource1.DataSource = typeof(Banque.BOL.Compte);
            // 
            // compteComboBox
            // 
            this.compteComboBox.DataSource = this.compteBindingSource;
            this.compteComboBox.DisplayMember = "LibelleCompte";
            this.compteComboBox.FormattingEnabled = true;
            this.compteComboBox.Location = new System.Drawing.Point(18, 36);
            this.compteComboBox.Name = "compteComboBox";
            this.compteComboBox.Size = new System.Drawing.Size(300, 24);
            this.compteComboBox.TabIndex = 11;
            this.compteComboBox.ValueMember = "CodeClient";
            this.compteComboBox.SelectedIndexChanged += new System.EventHandler(this.compteComboBox_SelectedIndexChanged);
            // 
            // BtnCreerCompte
            // 
            this.BtnCreerCompte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCreerCompte.Location = new System.Drawing.Point(354, 84);
            this.BtnCreerCompte.Name = "BtnCreerCompte";
            this.BtnCreerCompte.Size = new System.Drawing.Size(182, 23);
            this.BtnCreerCompte.TabIndex = 11;
            this.BtnCreerCompte.Text = "Nouveau compte Externe";
            this.BtnCreerCompte.UseVisualStyleBackColor = true;
            this.BtnCreerCompte.Click += new System.EventHandler(this.BtnCreerCompte_Click);
            // 
            // gbCaracteristiques
            // 
            this.gbCaracteristiques.Controls.Add(this.compteComboBox2);
            this.gbCaracteristiques.Controls.Add(this.LabelDate);
            this.gbCaracteristiques.Controls.Add(this.label4);
            this.gbCaracteristiques.Controls.Add(this.textBox3);
            this.gbCaracteristiques.Controls.Add(this.label3);
            this.gbCaracteristiques.Controls.Add(this.TxtMotif);
            this.gbCaracteristiques.Controls.Add(this.label2);
            this.gbCaracteristiques.Controls.Add(this.DatePrelevement);
            this.gbCaracteristiques.Controls.Add(this.label1);
            this.gbCaracteristiques.Controls.Add(this.Montanttxt);
            this.gbCaracteristiques.Controls.Add(libelleCompteLabel1);
            this.gbCaracteristiques.Controls.Add(this.libelleCompteTextBox1);
            this.gbCaracteristiques.Controls.Add(libelleCompteLabel);
            this.gbCaracteristiques.Controls.Add(this.libelleCompteTextBox);
            this.gbCaracteristiques.Controls.Add(this.btnAnnulerVirement);
            this.gbCaracteristiques.Controls.Add(this.btnValiderVirement);
            this.gbCaracteristiques.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCaracteristiques.Location = new System.Drawing.Point(6, 128);
            this.gbCaracteristiques.Name = "gbCaracteristiques";
            this.gbCaracteristiques.Size = new System.Drawing.Size(737, 374);
            this.gbCaracteristiques.TabIndex = 5;
            this.gbCaracteristiques.TabStop = false;
            this.gbCaracteristiques.Text = "Caractéristiques du virement";
            // 
            // compteComboBox2
            // 
            this.compteComboBox2.FormattingEnabled = true;
            this.compteComboBox2.Location = new System.Drawing.Point(417, 213);
            this.compteComboBox2.Name = "compteComboBox2";
            this.compteComboBox2.Size = new System.Drawing.Size(300, 21);
            this.compteComboBox2.TabIndex = 25;
            this.compteComboBox2.ValueMember = "CleRIB";
            // 
            // LabelDate
            // 
            this.LabelDate.AutoSize = true;
            this.LabelDate.Location = new System.Drawing.Point(392, 111);
            this.LabelDate.Name = "LabelDate";
            this.LabelDate.Size = new System.Drawing.Size(30, 13);
            this.LabelDate.TabIndex = 25;
            this.LabelDate.Text = "Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "Nom de beneficiaire : ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(142, 158);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(227, 20);
            this.textBox3.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Motif (facultatif)";
            // 
            // TxtMotif
            // 
            this.TxtMotif.Location = new System.Drawing.Point(142, 131);
            this.TxtMotif.Name = "TxtMotif";
            this.TxtMotif.Size = new System.Drawing.Size(227, 20);
            this.TxtMotif.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Date prelevement";
            // 
            // DatePrelevement
            // 
            this.DatePrelevement.Location = new System.Drawing.Point(142, 105);
            this.DatePrelevement.Name = "DatePrelevement";
            this.DatePrelevement.Size = new System.Drawing.Size(227, 20);
            this.DatePrelevement.TabIndex = 19;
            this.DatePrelevement.ValueChanged += new System.EventHandler(this.DatePrelevement_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Montant Virement";
            // 
            // Montanttxt
            // 
            this.Montanttxt.Location = new System.Drawing.Point(142, 80);
            this.Montanttxt.Name = "Montanttxt";
            this.Montanttxt.Size = new System.Drawing.Size(227, 20);
            this.Montanttxt.TabIndex = 17;
            this.Montanttxt.TextChanged += new System.EventHandler(this.Montanttxt_TextChanged);
            // 
            // libelleCompteTextBox1
            // 
            this.libelleCompteTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.compteBindingSource1, "LibelleCompte", true));
            this.libelleCompteTextBox1.Enabled = false;
            this.libelleCompteTextBox1.Location = new System.Drawing.Point(142, 54);
            this.libelleCompteTextBox1.Name = "libelleCompteTextBox1";
            this.libelleCompteTextBox1.Size = new System.Drawing.Size(227, 20);
            this.libelleCompteTextBox1.TabIndex = 16;
            // 
            // libelleCompteTextBox
            // 
            this.libelleCompteTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.compteBindingSource, "LibelleCompte", true));
            this.libelleCompteTextBox.Enabled = false;
            this.libelleCompteTextBox.Location = new System.Drawing.Point(142, 28);
            this.libelleCompteTextBox.Name = "libelleCompteTextBox";
            this.libelleCompteTextBox.Size = new System.Drawing.Size(227, 20);
            this.libelleCompteTextBox.TabIndex = 15;
            // 
            // btnAnnulerVirement
            // 
            this.btnAnnulerVirement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnulerVirement.Location = new System.Drawing.Point(101, 320);
            this.btnAnnulerVirement.Name = "btnAnnulerVirement";
            this.btnAnnulerVirement.Size = new System.Drawing.Size(72, 23);
            this.btnAnnulerVirement.TabIndex = 14;
            this.btnAnnulerVirement.Text = "Annuler";
            this.btnAnnulerVirement.UseVisualStyleBackColor = true;
            this.btnAnnulerVirement.Click += new System.EventHandler(this.btnValiderVirement_Click);
            // 
            // btnValiderVirement
            // 
            this.btnValiderVirement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValiderVirement.Location = new System.Drawing.Point(12, 320);
            this.btnValiderVirement.Name = "btnValiderVirement";
            this.btnValiderVirement.Size = new System.Drawing.Size(72, 23);
            this.btnValiderVirement.TabIndex = 14;
            this.btnValiderVirement.Text = "Valider";
            this.btnValiderVirement.UseVisualStyleBackColor = true;
            this.btnValiderVirement.Click += new System.EventHandler(this.btnValiderVirement_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmVirement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(896, 1150);
            this.Controls.Add(this.gbNouveauVirement);
            this.Controls.Add(this.gbClient);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "FrmVirement";
            this.Text = "Effectuez vos virements";
            this.gbClient.ResumeLayout(false);
            this.gbClient.PerformLayout();
            this.gbAdressePostale.ResumeLayout(false);
            this.gbAdressePostale.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.gbNouveauVirement.ResumeLayout(false);
            this.gbNouveauVirement.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.compteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.compteBindingSource1)).EndInit();
            this.gbCaracteristiques.ResumeLayout(false);
            this.gbCaracteristiques.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbClient;
     
        private System.Windows.Forms.BindingSource clientBindingSource;
        private System.Windows.Forms.GroupBox gbAdressePostale;
        private System.Windows.Forms.TextBox villeTextBox;
        private System.Windows.Forms.TextBox codePostalTextBox;
        private System.Windows.Forms.TextBox adresse2TextBox;
        private System.Windows.Forms.TextBox adresse1TextBox;
        private System.Windows.Forms.DateTimePicker dateDerniereConnexionDateTimePicker;
        private System.Windows.Forms.TextBox prénomClientTextBox;
        private System.Windows.Forms.TextBox nomClientTextBox;
        private System.Windows.Forms.TextBox codeClientTextBox;
        private System.Windows.Forms.GroupBox gbNouveauVirement;
        private System.Windows.Forms.GroupBox gbCaracteristiques;
        private System.Windows.Forms.Button btnValiderVirement;
        private System.Windows.Forms.Button BtnCreerCompte;
        private System.Windows.Forms.Button btnAnnulerVirement;
        private System.Windows.Forms.ComboBox compteComboBox;
        private System.Windows.Forms.BindingSource compteBindingSource;
        private System.Windows.Forms.ComboBox compteComboBox1;
        private System.Windows.Forms.BindingSource compteBindingSource1;
        private System.Windows.Forms.TextBox libelleCompteTextBox1;
        private System.Windows.Forms.TextBox libelleCompteTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtMotif;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker DatePrelevement;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Montanttxt;
        private System.Windows.Forms.Label LabelDate;
        private System.Windows.Forms.Label soldeLabel1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ComboBox compteComboBox2;
    }
}